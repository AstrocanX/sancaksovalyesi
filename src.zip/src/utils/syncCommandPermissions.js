// Artık bu yöntemi kullanmıyoruz.
// src/utils/syncCommandPermissions.js tamamen kaldırılmalı veya yorum yapılmalı.
